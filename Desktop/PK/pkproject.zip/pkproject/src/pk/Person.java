package pk;

/**
 * Person entity. @author MyEclipse Persistence Tools
 */

public class Person implements java.io.Serializable {

	// Fields

	private Integer EId;
	private String name;
	private String sex;
	private Integer birth;
	private Long perId;
	private Long tel;
	private String work;
	private String nativeplace;

	// Constructors

	/** default constructor */
	public Person() {
	}

	/** full constructor */
	public Person(String name, String sex, Integer birth,
			Long perId, Long tel, String work, String nativeplace) {
//		this.EId = EId;
		this.name = name;
		this.sex = sex;
		this.birth = birth;
		this.perId = perId;
		this.tel = tel;
		this.work = work;
		this.nativeplace = nativeplace;
	}

	// Property accessors

	public Integer getEId() {
		return this.EId;
	}

	public void setEId(Integer EId) {
		this.EId = EId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getBirth() {
		return this.birth;
	}

	public void setBirth(Integer birth) {
		this.birth = birth;
	}

	public Long getPerId() {
		return this.perId;
	}

	public void setPerId(Long perId) {
		this.perId = perId;
	}

	public Long getTel() {
		return this.tel;
	}

	public void setTel(Long tel) {
		this.tel = tel;
	}

	public String getWork() {
		return this.work;
	}

	public void setWork(String work) {
		this.work = work;
	}

	public String getNativeplace() {
		return this.nativeplace;
	}

	public void setNativeplace(String nativeplace) {
		this.nativeplace = nativeplace;
	}

}