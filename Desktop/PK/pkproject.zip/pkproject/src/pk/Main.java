/*
 * Main.java
 *
 * Created on __DATE__, __TIME__
 */

package pk;

import java.util.List;

import javax.swing.JOptionPane;

/**
 *
 * @author  __USER__
 */
public class Main extends javax.swing.JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** Creates new form Main */
	private String xname, xsex, xwork, xnativeplace;
	private int xbirth;
	private long xperid, xtel;

	public Main() {
		System.out.println("init activity");
		initComponents();

	}

	//Font font=textArea2.getFont();
	//textArea2.setFont(new Font(font.getName(), font.getStyle(), 20));

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel1 = new javax.swing.JPanel();
		Ա������ = new java.awt.Label();
		textField1 = new java.awt.TextField();
		label1 = new java.awt.Label();
		jLabel1 = new javax.swing.JLabel();
		textField2 = new java.awt.TextField();
		textField3 = new java.awt.TextField();
		label2 = new java.awt.Label();
		textField4 = new java.awt.TextField();
		label3 = new java.awt.Label();
		textField5 = new java.awt.TextField();
		jLabel2 = new javax.swing.JLabel();
		textField6 = new java.awt.TextField();
		label4 = new java.awt.Label();
		textField7 = new java.awt.TextField();
		label5 = new java.awt.Label();
		button1 = new java.awt.Button();
		jPanel2 = new javax.swing.JPanel();
		label6 = new java.awt.Label();
		label7 = new java.awt.Label();
		textField8 = new java.awt.TextField();
		button2 = new java.awt.Button();
		jPanel3 = new javax.swing.JPanel();
		label8 = new java.awt.Label();
		label13 = new java.awt.Label();
		textField16 = new java.awt.TextField();
		label9 = new java.awt.Label();
		label10 = new java.awt.Label();
		label11 = new java.awt.Label();
		label12 = new java.awt.Label();
		label17 = new java.awt.Label();
		label18 = new java.awt.Label();
		label19 = new java.awt.Label();
		textField9 = new java.awt.TextField();
		textField10 = new java.awt.TextField();
		textField11 = new java.awt.TextField();
		textField12 = new java.awt.TextField();
		textField13 = new java.awt.TextField();
		textField14 = new java.awt.TextField();
		textField15 = new java.awt.TextField();
		button3 = new java.awt.Button();
		jPanel4 = new javax.swing.JPanel();
		label14 = new java.awt.Label();
		textArea1 = new java.awt.TextArea();
		button5 = new java.awt.Button();
		jPanel5 = new javax.swing.JPanel();
		label15 = new java.awt.Label();
		textArea2 = new java.awt.TextArea();
		label16 = new java.awt.Label();
		textField17 = new java.awt.TextField();
		button4 = new java.awt.Button();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("please \uff01~\u679c\u6c41\u5458\u5de5\u4fe1\u606f\u7ba1\u7406\uff01~");

		jTabbedPane1.setBackground(new java.awt.Color(51, 0, 102));
		jTabbedPane1.setForeground(new java.awt.Color(255, 204, 0));

		jPanel1.setBackground(new java.awt.Color(204, 255, 204));

		Ա������.setText("\u5458\u5de5\u59d3\u540d");

		

		label1.setText("\u6027\u522b");

		jLabel1.setFont(new java.awt.Font("Dialog", 0, 12));
		jLabel1.setText("\u8054\u7cfb\u7535\u8bdd");

		label2.setText("\u51fa\u751f\u5e74\u6708");

		label3.setText("\u8eab\u4efd\u8bc1\u53f7");

		jLabel2.setFont(new java.awt.Font("Dialog", 0, 12));
		jLabel2.setText("\u7c4d\u8d2f");

		label4.setText("\u62c5\u4efb\u804c\u52a1");

		label5.setAlignment(java.awt.Label.CENTER);
		label5.setBackground(new java.awt.Color(255, 204, 255));
		label5.setFont(new java.awt.Font("����", 1, 24));
		label5.setForeground(new java.awt.Color(0, 0, 102));
		label5.setText("\u6dfb\u52a0\u5458\u5de5\u4fe1\u606f");

		button1.setLabel("\u786e\u8ba4\u6dfb\u52a0");
		button1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				button1ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(89, 89, 89)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																label5,
																javax.swing.GroupLayout.Alignment.TRAILING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																169,
																Short.MAX_VALUE)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								Ա������,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								label1,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								label2,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								label3,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								52,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel1)
																						.addComponent(
																								label4,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								52,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel2))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								textField6,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								107,
																								Short.MAX_VALUE)
																						.addComponent(
																								textField1,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								107,
																								Short.MAX_VALUE)
																						.addGroup(
																								jPanel1Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.TRAILING,
																												false)
																										.addComponent(
																												textField7,
																												javax.swing.GroupLayout.Alignment.LEADING,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												textField2,
																												javax.swing.GroupLayout.Alignment.LEADING,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												textField3,
																												javax.swing.GroupLayout.Alignment.LEADING,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												textField4,
																												javax.swing.GroupLayout.Alignment.LEADING,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												textField5,
																												javax.swing.GroupLayout.Alignment.LEADING,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												107,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))))
										.addGap(31, 31, 31)
										.addComponent(
												button1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(318, 318, 318)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				button1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(19,
																				19,
																				19)
																		.addComponent(
																				label5,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(20,
																				20,
																				20)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								Ա������,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								22,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								textField1,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								22,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addGap(11,
																				11,
																				11)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												label1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												label2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												textField2,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												textField3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												22,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								false)
																						.addComponent(
																								label3,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								textField4,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								22,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								textField5,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								22,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel1))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								false)
																						.addComponent(
																								label4,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								textField7,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								textField6,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel2))))
										.addGap(158, 158, 158)));

		jTabbedPane1.addTab("\u6dfb\u52a0\u5458\u5de5", jPanel1);

		jPanel2.setBackground(new java.awt.Color(255, 255, 153));

		label6.setAlignment(java.awt.Label.CENTER);
		label6.setBackground(new java.awt.Color(204, 255, 204));
		label6.setFont(new java.awt.Font("����", 1, 24));
		label6.setForeground(new java.awt.Color(153, 0, 0));
		label6.setText("\u5220\u9664\u5458\u5de5");

		label7.setFont(new java.awt.Font("����", 0, 18));
		label7.setText("\u8bf7\u8f93\u5165\u8981\u5220\u9664\u7684\u5458\u5de5\u7684\u5458\u5de5\u7f16\u53f7");

		button2.setLabel("\u786e\u8ba4\u5220\u9664");
		button2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				button2ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(47, 47, 47)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																label6,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																118,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				label7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addComponent(
																				textField8,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				42,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
										.addGap(316, 316, 316))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addGap(300, 300, 300)
										.addComponent(
												button2,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addGap(307, 307, 307)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(50,
																				50,
																				50)
																		.addComponent(
																				label6,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				33,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				label7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				67,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(117,
																				117,
																				117)
																		.addComponent(
																				textField8,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												91, Short.MAX_VALUE)
										.addComponent(
												button2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(78, 78, 78)));

		jTabbedPane1.addTab("\u5220\u9664\u5458\u5de5", jPanel2);

		jPanel3.setBackground(new java.awt.Color(255, 204, 255));

		label8.setAlignment(java.awt.Label.CENTER);
		label8.setBackground(new java.awt.Color(204, 255, 204));
		label8.setFont(new java.awt.Font("����", 1, 24));
		label8.setForeground(new java.awt.Color(0, 0, 102));
		label8.setText("\u4fee\u6539\u5458\u5de5\u4fe1\u606f");

		label13.setFont(new java.awt.Font("����", 0, 18));
		label13.setForeground(new java.awt.Color(0, 102, 102));
		label13.setText("\u8981\u4fee\u6539\u7684\u5458\u5de5\u7f16\u53f7");

		label9.setText("\u5458\u5de5\u59d3\u540d");

		label10.setText("\u6027\u522b");

		label11.setText("\u51fa\u751f\u5e74\u6708");

		label12.setText("\u8eab\u4efd\u8bc1\u53f7");

		label17.setText("\u8054\u7cfb\u7535\u8bdd");

		label18.setText("\u62c5\u4efb\u804c\u52a1");

		label19.setText("\u7c4d\u8d2f");

		button3.setLabel("\u786e\u8ba4\u4fee\u6539");
		button3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				button3ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(46, 46, 46)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addComponent(
																				label18,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap())
														.addGroup(
																jPanel3Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(
																				jPanel3Layout
																						.createSequentialGroup()
																						.addComponent(
																								label8,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								225,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addContainerGap(
																								177,
																								Short.MAX_VALUE))
																		.addGroup(
																				jPanel3Layout
																						.createSequentialGroup()
																						.addGroup(
																								jPanel3Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addGroup(
																												jPanel3Layout
																														.createSequentialGroup()
																														.addComponent(
																																label19,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addGap(228,
																																228,
																																228))
																										.addGroup(
																												jPanel3Layout
																														.createSequentialGroup()
																														.addGroup(
																																jPanel3Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addGroup(
																																				jPanel3Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								label12,
																																								javax.swing.GroupLayout.PREFERRED_SIZE,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								javax.swing.GroupLayout.PREFERRED_SIZE)
																																						.addGap(31,
																																								31,
																																								31)
																																						.addComponent(
																																								textField12,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								134,
																																								Short.MAX_VALUE))
																																		.addGroup(
																																				jPanel3Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								label11,
																																								javax.swing.GroupLayout.PREFERRED_SIZE,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								javax.swing.GroupLayout.PREFERRED_SIZE)
																																						.addGap(31,
																																								31,
																																								31)
																																						.addComponent(
																																								textField11,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								134,
																																								Short.MAX_VALUE))
																																		.addGroup(
																																				jPanel3Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								label10,
																																								javax.swing.GroupLayout.PREFERRED_SIZE,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								javax.swing.GroupLayout.PREFERRED_SIZE)
																																						.addGap(55,
																																								55,
																																								55)
																																						.addComponent(
																																								textField10,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								134,
																																								Short.MAX_VALUE))
																																		.addGroup(
																																				jPanel3Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.TRAILING,
																																								false)
																																						.addGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING,
																																								jPanel3Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												label9,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addGap(31,
																																												31,
																																												31)
																																										.addComponent(
																																												textField9,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												Short.MAX_VALUE))
																																						.addGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING,
																																								jPanel3Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												label13,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addGap(24,
																																												24,
																																												24)
																																										.addComponent(
																																												textField16,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												45,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																																		.addGroup(
																																				jPanel3Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								label17,
																																								javax.swing.GroupLayout.PREFERRED_SIZE,
																																								javax.swing.GroupLayout.DEFAULT_SIZE,
																																								javax.swing.GroupLayout.PREFERRED_SIZE)
																																						.addGap(31,
																																								31,
																																								31)
																																						.addGroup(
																																								jPanel3Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.LEADING)
																																										.addComponent(
																																												textField14,
																																												javax.swing.GroupLayout.Alignment.TRAILING,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												134,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												textField13,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												134,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												textField15,
																																												javax.swing.GroupLayout.Alignment.TRAILING,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												134,
																																												javax.swing.GroupLayout.PREFERRED_SIZE))))
																														.addGap(39,
																																39,
																																39)))
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								button3,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								83,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addGap(286,
																								286,
																								286))))));
		jPanel3Layout
				.setVerticalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel3Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												label8,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												33,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																label13,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																textField16,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																false)
														.addComponent(
																textField9,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addComponent(
																label9,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																label10,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																textField10,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																label11,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																textField11,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																22,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																textField12,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																22,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																label12,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addComponent(
																				label17,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				label18,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				label19,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(4,
																				4,
																				4)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								button3,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addGroup(
																								jPanel3Layout
																										.createSequentialGroup()
																										.addComponent(
																												textField13,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												22,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												textField14,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												textField15,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))))
										.addGap(133, 133, 133)));

		jTabbedPane1.addTab("\u4fee\u6539\u5458\u5de5\u4fe1\u606f", jPanel3);

		jPanel4.setBackground(new java.awt.Color(153, 255, 204));

		label14.setAlignment(java.awt.Label.CENTER);
		label14.setBackground(new java.awt.Color(255, 255, 153));
		label14.setFont(new java.awt.Font("����", 1, 24));
		label14.setForeground(new java.awt.Color(0, 0, 102));
		label14.setText("\u67e5\u770b\u5458\u5de5\u4fe1\u606f");

		button5.setLabel("\u786e\u5b9a\u67e5\u770b");
		button5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				button5ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(26, 26, 26)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				textArea1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				338,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap())
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				label14,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGap(78,
																				78,
																				78)
																		.addComponent(
																				button5,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(356,
																				356,
																				356)))));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(30, 30, 30)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																label14,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																button5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(19, 19, 19)
										.addComponent(
												textArea1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												219,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(54, Short.MAX_VALUE)));

		jTabbedPane1.addTab("\u67e5\u770b\u5458\u5de5\u4fe1\u606f", jPanel4);

		jPanel5.setBackground(new java.awt.Color(255, 204, 102));
		jPanel5.setToolTipText("\u6309\u59d3\u540d\u67e5\u627e\u5458\u5de5");

		label15.setAlignment(java.awt.Label.CENTER);
		label15.setBackground(new java.awt.Color(204, 255, 255));
		label15.setFont(new java.awt.Font("����", 1, 24));
		label15.setForeground(new java.awt.Color(0, 0, 102));
		label15.setText("\u6309\u6761\u4ef6\u67e5\u627e\u5458\u5de5");

		label16.setFont(new java.awt.Font("Dialog", 1, 18));
		label16.setForeground(new java.awt.Color(255, 255, 255));
		label16.setText("\u8f93\u5165\u67e5\u627e\u5458\u5de5\u7684\u7f16\u53f7");

		button4.setFont(new java.awt.Font("Dialog", 0, 14));
		button4.setForeground(new java.awt.Color(255, 0, 0));
		button4.setLabel("\u786e\u5b9a");
		button4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				button4ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(
				jPanel5);
		jPanel5.setLayout(jPanel5Layout);
		jPanel5Layout
				.setHorizontalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addGap(50, 50, 50)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel5Layout
																		.createSequentialGroup()
																		.addComponent(
																				label16,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				textField17,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				55,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(29,
																				29,
																				29)
																		.addComponent(
																				button4,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				56,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(296,
																				296,
																				296))
														.addGroup(
																jPanel5Layout
																		.createSequentialGroup()
																		.addComponent(
																				label15,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGap(442,
																				442,
																				442))))
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addGap(54, 54, 54)
										.addComponent(
												textArea2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												336,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(281, Short.MAX_VALUE)));
		jPanel5Layout
				.setVerticalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addGap(43, 43, 43)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel5Layout
																		.createSequentialGroup()
																		.addComponent(
																				label15,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				label16,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel5Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(
																				textField17,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				28,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(
																				button4,
																				javax.swing.GroupLayout.Alignment.TRAILING,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGap(22, 22, 22)
										.addComponent(
												textArea2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												130,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(87, Short.MAX_VALUE)));

		jTabbedPane1.addTab("\u6309\u6761\u4ef6\u67e5\u627e\u5458\u5de5",
				jPanel5);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 417,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 386,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void button5ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		PersonDAO personDAO = new PersonDAO();
		List<Person> row = personDAO.findAll();
		String putout = "";
		for (int i = 0; i < row.size(); i++) {
			putout += "Ա����ţ�" + row.get(i).getEId() + "\n������"
					+ row.get(i).getName() + "\n�Ա�" + row.get(i).getSex()
					+ "\n�������£�" + row.get(i).getBirth() + "\n����֤�ţ�"
					+ row.get(i).getPerId() + "\n��ϵ�绰��" + row.get(i).getTel()
					+ "\n����ְ��" + row.get(i).getWork() + "\n���᣺"
					+ row.get(i).getNativeplace() + "\n";
		}
		textArea1.setText(putout);
		JOptionPane.showMessageDialog(null, "�ҵ����ҵ������쿴�ϣ�");
	}

	private void button4ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		int inputeid = Integer.parseInt(textField17.getText());
		PersonDAO personDAO = new PersonDAO();
		if (personDAO.findById(inputeid) != null) {
			String putout = "Ա����ţ�" + personDAO.findById(inputeid).getEId()
					+ "\n������" + personDAO.findById(inputeid).getName()
					+ "\n�Ա�" + personDAO.findById(inputeid).getSex()
					+ "\n�������£�" + personDAO.findById(inputeid).getBirth()
					+ "\n����֤�ţ�" + personDAO.findById(inputeid).getPerId()
					+ "\n��ϵ�绰��" + personDAO.findById(inputeid).getTel()
					+ "\n����ְ��" + personDAO.findById(inputeid).getWork()
					+ "\n���᣺" + personDAO.findById(inputeid).getNativeplace();
			textArea2.setText(putout);
			JOptionPane.showMessageDialog(null, "�ҵ����ҵ������쿴�ϣ�");
		} else {
			JOptionPane.showMessageDialog(null, "��Ҫ���ҵ�Ա�������ڣ��ǲ��Ǳ����������أ�");
		}
	}

	private void button3ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		int inputeid = Integer.parseInt(textField16.getText());
		PersonDAO personDAO = new PersonDAO();
		if (personDAO.findById(inputeid) != null) {
			xname = textField9.getText();
			xsex = textField10.getText();
			xbirth = Integer.parseInt(textField11.getText());
			xperid = Long.parseLong(textField12.getText());
			xtel = Long.parseLong(textField13.getText());
			xwork = textField14.getText();
			xnativeplace = textField15.getText();
			personDAO.findById(inputeid).setName(xname);
			personDAO.findById(inputeid).setBirth(xbirth);
			personDAO.findById(inputeid).setNativeplace(xnativeplace);
			personDAO.findById(inputeid).setSex(xsex);
			personDAO.findById(inputeid).setTel(xtel);
			personDAO.findById(inputeid).setPerId(xperid);
			personDAO.findById(inputeid).setWork(xwork);
			personDAO.attachDirty(personDAO.findById(inputeid));
			JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
		} else {
			JOptionPane.showMessageDialog(null, "��Ҫ�޸ĵ�Ա�������ڣ����ٲ鿴һ������ı���Ƿ�����");
		}
	}

	private void button2ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		int inputeid = Integer.parseInt(textField8.getText());
		PersonDAO personDAO = new PersonDAO();
		if (personDAO.findById(inputeid) != null) {
			personDAO.delete(personDAO.findById(inputeid));
			JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
		} else {
			JOptionPane.showMessageDialog(null, "��Ҫɾ����Ա�������ڣ��һ��������ѱ������ˣ�");
		}
	}

	private void button1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		xname = textField1.getText();
		xsex = textField2.getText();
		xbirth = Integer.parseInt(textField3.getText());
		xperid = Long.parseLong(textField4.getText());
		xtel = Long.parseLong(textField5.getText());
		xwork = textField7.getText();
		xnativeplace = textField6.getText();
		Person temp = new Person(xname, xsex, xbirth, xperid, xtel, xwork,
				xnativeplace);
		/*temp.setEId(null);
		temp.setName(xname);
		temp.setBirth(xbirth);
		temp.setNativeplace(xnativeplace);
		temp.setSex(xsex);
		temp.setTel(xtel);
		temp.setPerId(xperid);
		temp.setWork(xwork);*/
		PersonDAO personDao = new PersonDAO();
		personDao.save(temp);
		JOptionPane.showMessageDialog(null, "���ӳɹ���");
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Main().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private java.awt.Button button1;
	private java.awt.Button button2;
	private java.awt.Button button3;
	private java.awt.Button button4;
	private java.awt.Button button5;

	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JPanel jPanel5;
	private javax.swing.JTabbedPane jTabbedPane1;
	private java.awt.Label label1;
	private java.awt.Label label10;
	private java.awt.Label label11;
	private java.awt.Label label12;
	private java.awt.Label label13;
	private java.awt.Label label14;
	private java.awt.Label label15;
	private java.awt.Label label16;
	private java.awt.Label label17;
	private java.awt.Label label18;
	private java.awt.Label label19;
	private java.awt.Label label2;
	private java.awt.Label label3;
	private java.awt.Label label4;
	private java.awt.Label label5;
	private java.awt.Label label6;
	private java.awt.Label label7;
	private java.awt.Label label8;
	private java.awt.Label label9;
	private java.awt.TextArea textArea1;
	private java.awt.TextArea textArea2;
	private java.awt.TextField textField1;
	private java.awt.TextField textField10;
	private java.awt.TextField textField11;
	private java.awt.TextField textField12;
	private java.awt.TextField textField13;
	private java.awt.TextField textField14;
	private java.awt.TextField textField15;
	private java.awt.TextField textField16;
	private java.awt.TextField textField17;
	private java.awt.TextField textField2;
	private java.awt.TextField textField3;
	private java.awt.TextField textField4;
	private java.awt.TextField textField5;
	private java.awt.TextField textField6;
	private java.awt.TextField textField7;
	private java.awt.TextField textField8;
	private java.awt.TextField textField9;
	private java.awt.Label Ա������;
	// End of variables declaration//GEN-END:variables

}